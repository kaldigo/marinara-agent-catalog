import {
  clearPromptContribution,
  getPromptContribution,
  listPromptContributions,
  registerPromptContributionBridge,
  registerPromptContributor,
  setPromptContribution,
} from "../../bridge/prompt-contribution.js";
import { injectHostJson } from "../../bridge/host-routes.js";
import {
  GROUP_SORT_ORDER_AGENT_TYPE,
  buildCandidateHash,
  buildInstructionText,
  deriveNextSpeaker,
  isGroupSortEnabled,
  normalizeGroupSortState,
  normalizeObject,
  parseSmartGroupSelectionIds,
  parseTerminalNextSpeakerMarker,
  readGroupSortState,
  resolveActiveCharacterIds,
  stripTerminalNextSpeakerMarker,
  upsertAnchor,
  writeGroupSortState,
} from "../shared/state.js";

const REQUEST_STATE = new WeakMap();
const INTERNAL_HEADER = "x-group-sort-order-internal";

export function registerGroupSortHooks({ app, runtime }) {
  const cleanupBridge = registerPromptContributionBridge({ app, runtime, internalHeader: INTERNAL_HEADER });
  const cleanupContributor = registerPromptContributor({
    agentType: GROUP_SORT_ORDER_AGENT_TYPE,
    agentName: "Group Sort Order",
    resolve: async ({ body, chatId }) => {
      if (body.impersonate === true || body.turnGameBots === true) return null;
      const chat = await runtime.persistence.getChat(chatId);
      if (!chat || !isGroupSortEnabled(chat)) return null;
      const state = readGroupSortState(chat.metadata);
      const candidates = await resolveCandidates(runtime, chat, state);
      if (candidates.length <= 2) return null;
      return buildInstructionText(candidates);
    },
  });
  app.addHook("preHandler", async (request, reply) => {
    await prepareGeneration({ runtime, request, reply });
  });
  app.addHook("onResponse", async (request, reply) => {
    try {
      await finishGeneration({ app, runtime, request, reply });
    } catch (error) {
      runtime.logger.warn(error, "[Group Sort Order] generation hook failed");
    }
  });
  return () => {
    cleanupContributor();
    cleanupBridge();
  };
}

export function createGroupSortRoutes({ app, runtime }) {
  app.get("/chat/:chatId/state", async (req, reply) => {
    const chat = await runtime.persistence.getChat(req.params.chatId);
    if (!chat) return reply.status(404).send({ error: "Chat not found" });
    const view = await buildView(runtime, chat);
    return { ok: true, ...view };
  });

  app.post("/chat/:chatId/ensure", async (req, reply) => {
    const chat = await runtime.persistence.getChat(req.params.chatId);
    if (!chat) return reply.status(404).send({ error: "Chat not found" });
    if (!isGroupSortEnabled(chat)) {
      clearGroupSortPromptContribution(chat.id);
      return { ok: true, clearedContribution: true, ...(await buildView(runtime, chat)) };
    }
    const body = normalizeObject(req.body);
    const current = readGroupSortState(chat.metadata);
    const personaCandidate = normalizePersonaCandidate(body.personaCandidate) ?? current.personaCandidate;
    const includePersonaCandidate =
      typeof body.includePersonaCandidate === "boolean" ? body.includePersonaCandidate : current.includePersonaCandidate;
    const candidates = await resolveCandidates(runtime, chat, { includePersonaCandidate, personaCandidate });
    const candidateHash = buildCandidateHash(candidates, { includePersonaCandidate });
    await patchChatState(runtime, chat, {
      includePersonaCandidate,
      personaCandidate,
      candidateHash,
      byAnchor: candidates.length <= 2 ? {} : current.byAnchor,
    });
    reconcileGroupSortPromptContribution(chat.id, candidates);
    return { ok: true, ...(await buildView(runtime, (await runtime.persistence.getChat(chat.id)) || chat)) };
  });

  app.patch("/chat/:chatId/settings", async (req, reply) => {
    const chat = await runtime.persistence.getChat(req.params.chatId);
    if (!chat) return reply.status(404).send({ error: "Chat not found" });
    const body = normalizeObject(req.body);
    const current = readGroupSortState(chat.metadata);
    const includePersonaCandidate =
      typeof body.includePersonaCandidate === "boolean" ? body.includePersonaCandidate : current.includePersonaCandidate;
    const personaCandidate = normalizePersonaCandidate(body.personaCandidate) ?? current.personaCandidate;
    await patchChatState(runtime, chat, { includePersonaCandidate, personaCandidate });
    const freshChat = (await runtime.persistence.getChat(chat.id)) || chat;
    const view = await buildView(runtime, freshChat);
    reconcileGroupSortPromptContribution(chat.id, view.candidates);
    return { ok: true, ...view };
  });

  app.post("/chat/:chatId/refresh", async (req, reply) => {
    const chat = await runtime.persistence.getChat(req.params.chatId);
    if (!chat) return reply.status(404).send({ error: "Chat not found" });
    const view = await buildView(runtime, chat);
    if (!view.enabled || view.candidates.length <= 2) return { ok: true, refreshed: false, ...view };
    const selected = await refreshSmartSelection({
      app,
      runtime,
      chat,
      candidates: view.candidates,
      candidateHash: view.candidateHash,
      personaName: resolvePersonaName(chat, view.candidates, readGroupSortState(chat.metadata)),
    });
    const freshChat = (await runtime.persistence.getChat(chat.id)) || chat;
    return { ok: true, refreshed: selected !== null, selectedSpeakerId: selected?.id ?? null, ...(await buildView(runtime, freshChat)) };
  });

  app.get("/prompt-contributions/:chatId", async (req) => {
    return { ok: true, chatId: req.params.chatId, contributions: listPromptContributions(req.params.chatId) };
  });

  app.get("/prompt-contributions/:chatId/:agentType", async (req) => {
    return {
      ok: true,
      chatId: req.params.chatId,
      agentType: req.params.agentType,
      contribution: getPromptContribution(req.params.chatId, req.params.agentType),
    };
  });

  app.put("/prompt-contributions/:chatId/:agentType", async (req) => {
    const body = normalizeObject(req.body);
    const text = body.text === null ? null : typeof body.text === "string" ? body.text : "";
    const contribution = setPromptContribution(req.params.chatId, {
      agentType: req.params.agentType,
      agentName: typeof body.agentName === "string" ? body.agentName : req.params.agentType,
      text,
    });
    return {
      ok: true,
      chatId: req.params.chatId,
      agentType: req.params.agentType,
      contribution,
    };
  });

  app.delete("/prompt-contributions/:chatId/:agentType", async (req) => {
    return {
      ok: true,
      chatId: req.params.chatId,
      agentType: req.params.agentType,
      cleared: clearPromptContribution(req.params.chatId, req.params.agentType),
    };
  });
}

async function prepareGeneration({ runtime, request, reply }) {
  if (isInternalRequest(request)) return;
  if (String(request.method || "").toUpperCase() !== "POST") return;
  if (!/^\/api\/generate(?:[?#].*)?$/u.test(String(request.url || ""))) return;
  const body = normalizeObject(request.body);
  if (body.impersonate === true || body.turnGameBots === true) return;
  const chatId = typeof body.chatId === "string" ? body.chatId : "";
  if (!chatId) return;
  const requestState = {
    chatId,
    beforeMessageIds: new Set(),
    candidateHash: "",
    candidateIds: [],
    targetMessageId: readString(body.regenerateMessageId) || readString(body.continueMessageId),
  };
  REQUEST_STATE.set(request, requestState);
  installOutgoingMarkerFilter(reply, requestState);
  const chat = await runtime.persistence.getChat(chatId);
  if (!chat) return;
  const groupSortEnabled = isGroupSortEnabled(chat);
  if (!groupSortEnabled) return;
  const messages = await runtime.persistence.listMessages(chatId);
  const candidates = await resolveCandidates(runtime, chat, readGroupSortState(chat.metadata));
  const candidateHash = buildCandidateHash(candidates, { includePersonaCandidate: readGroupSortState(chat.metadata).includePersonaCandidate });
  requestState.beforeMessageIds = new Set(messages.map((message) => message.id));
  requestState.candidateHash = candidateHash;
  requestState.candidateIds = candidates.map((c) => c.id);
  if (candidates.length <= 2) return;

  const hasIncomingUserTurn = hasVisibleIncomingUserTurn(body);
  const next = hasIncomingUserTurn
    ? null
    : deriveNextSpeaker({ state: readGroupSortState(chat.metadata), messages, candidates, candidateHash });
  if (next && next.kind !== "persona" && !body.forCharacterId) {
    body.forCharacterId = next.id;
  }
  request.body = body;
}

async function finishGeneration({ app, runtime, request, reply }) {
  if (reply.statusCode < 200 || reply.statusCode >= 300) return;
  if (isInternalRequest(request)) return;
  if (String(request.method || "").toUpperCase() !== "POST") return;
  if (!/^\/api\/generate(?:[?#].*)?$/u.test(String(request.url || ""))) return;
  const body = normalizeObject(request.body);
  if (body.impersonate === true || body.turnGameBots === true) return;
  const storedRequestState = REQUEST_STATE.get(request);
  if (storedRequestState) REQUEST_STATE.delete(request);
  const chatId = storedRequestState?.chatId || readString(body.chatId);
  if (!chatId) return;
  const chat = await runtime.persistence.getChat(chatId);
  if (!chat) return;
  const groupSortEnabled = isGroupSortEnabled(chat);
  const messages = await runtime.persistence.listMessages(chatId);
  const currentState = readGroupSortState(chat.metadata);
  const targetMessageId =
    storedRequestState?.targetMessageId || readString(body.regenerateMessageId) || readString(body.continueMessageId);
  const target = resolveGeneratedAssistantTarget({
    messages,
    beforeMessageIds: storedRequestState?.beforeMessageIds,
    targetMessageId,
  });
  if (!target) return;
  const parsed = parseTerminalNextSpeakerMarker(target.content) || resolveOutgoingMarkerForTarget(storedRequestState, target);
  if (!parsed) return;
  const cleaned = stripTerminalNextSpeakerMarker(target.content);
  if (cleaned !== target.content) {
    await injectJson(
      app,
      "PATCH",
      `/api/chats/${encodeURIComponent(chatId)}/messages/${encodeURIComponent(target.id)}`,
      { content: cleaned },
    );
  }
  if (!groupSortEnabled) return;
  const candidates = await resolveCandidates(runtime, chat, currentState);
  const candidateHash =
    storedRequestState?.candidateHash || buildCandidateHash(candidates, { includePersonaCandidate: currentState.includePersonaCandidate });
  const candidateIds = storedRequestState?.candidateIds?.length
    ? storedRequestState.candidateIds
    : candidates.map((candidate) => candidate.id);
  if (!candidateIds.includes(parsed.speakerId)) {
    runtime.logger.warn(
      "[Group Sort Order] stripped next_speaker marker with unknown candidate %s in chat %s",
      parsed.speakerId,
      chatId,
    );
    return;
  }
  const nextState = upsertAnchor(currentState, {
    messageId: target.id,
    swipeIndex: Number.isInteger(target.activeSwipeIndex) ? target.activeSwipeIndex : 0,
    messageSpeakerId: target.characterId ?? "",
    nextSpeakerId: parsed.speakerId,
    candidateHash,
  });
  await patchChatState(runtime, chat, nextState);
}

export function resolveGeneratedAssistantTarget({ messages, beforeMessageIds, targetMessageId }) {
  const list = Array.isArray(messages) ? messages : [];
  if (targetMessageId) {
    const explicit = list.find(
      (message) => message?.id === targetMessageId && message.role === "assistant" && typeof message.content === "string",
    );
    if (explicit) return explicit;
  }
  const created =
    beforeMessageIds instanceof Set ? list.filter((message) => message?.id && !beforeMessageIds.has(message.id)) : [];
  const fromCreated = [...created]
    .reverse()
    .find((message) => message.role === "assistant" && typeof message.content === "string");
  if (fromCreated) return fromCreated;
  return [...list].reverse().find((message) => message.role === "assistant" && typeof message.content === "string") ?? null;
}

export function sanitizeOutgoingSseChunk(chunk, requestState) {
  const text = chunkToString(chunk);
  if (!text || !/next_speaker/iu.test(text)) return chunk;
  const sanitized = text.replace(/^data: (.+)$/gmu, (line, rawPayload) => {
    const payloads = sanitizeOutgoingSsePayload(rawPayload, requestState);
    if (!payloads) return line;
    const list = Array.isArray(payloads) ? payloads : [payloads];
    return list.map((payload) => `data: ${JSON.stringify(payload)}`).join("\n\n");
  });
  if (sanitized === text) return chunk;
  if (Buffer.isBuffer(chunk)) return Buffer.from(sanitized);
  return sanitized;
}

export function sanitizeOutgoingSsePayload(rawPayload, requestState) {
  let payload;
  try {
    payload = JSON.parse(String(rawPayload || ""));
  } catch {
    return null;
  }
  const obj = normalizeObject(payload);
  if (obj.type === "message_saved") {
    const data = normalizeObject(obj.data);
    if (typeof data.content !== "string") return null;
    const parsed = parseTerminalNextSpeakerMarker(data.content);
    if (!parsed) return null;
    requestState.outgoingMarker = {
      messageId: readString(data.id),
      swipeIndex: Number.isInteger(data.activeSwipeIndex) ? data.activeSwipeIndex : 0,
      messageSpeakerId: readString(data.characterId),
      nextSpeakerId: parsed.speakerId,
    };
    const cleaned = stripTerminalNextSpeakerMarker(data.content);
    const cleanedMessage = { ...obj, data: { ...data, content: cleaned } };
    return cleaned !== data.content ? [{ type: "content_replace", data: cleaned }, cleanedMessage] : cleanedMessage;
  }
  if (obj.type === "content_replace" && typeof obj.data === "string") {
    const parsed = parseTerminalNextSpeakerMarker(obj.data);
    if (!parsed) return null;
    requestState.outgoingMarker = {
      ...(normalizeObject(requestState.outgoingMarker) || {}),
      nextSpeakerId: parsed.speakerId,
    };
    return { ...obj, data: stripTerminalNextSpeakerMarker(obj.data) };
  }
  if (obj.type === "text_rewrite") {
    const data = normalizeObject(obj.data);
    if (typeof data.editedText !== "string") return null;
    const parsed = parseTerminalNextSpeakerMarker(data.editedText);
    if (!parsed) return null;
    requestState.outgoingMarker = {
      ...(normalizeObject(requestState.outgoingMarker) || {}),
      nextSpeakerId: parsed.speakerId,
    };
    return { ...obj, data: { ...data, editedText: stripTerminalNextSpeakerMarker(data.editedText) } };
  }
  return null;
}

function resolveOutgoingMarkerForTarget(requestState, target) {
  const marker = normalizeObject(requestState?.outgoingMarker);
  const speakerId = readString(marker.nextSpeakerId);
  if (!speakerId) return null;
  const markerMessageId = readString(marker.messageId);
  if (markerMessageId && markerMessageId !== target?.id) return null;
  return { speakerId };
}

async function buildView(runtime, chat) {
  const state = readGroupSortState(chat.metadata);
  const messages = await runtime.persistence.listMessages(chat.id);
  const candidates = await resolveCandidates(runtime, chat, state);
  const availableCandidateCount = resolveAvailableCandidateCount(chat, state);
  const candidateHash = buildCandidateHash(candidates, { includePersonaCandidate: state.includePersonaCandidate });
  const next = candidates.length > 2 ? deriveNextSpeaker({ state, messages, candidates, candidateHash }) : null;
  return {
    chatId: chat.id,
    enabled: isGroupSortEnabled(chat),
    includePersonaCandidate: state.includePersonaCandidate,
    candidates,
    candidateHash,
    nextSpeaker: next,
    status: next ? "known" : "unknown",
    canRefresh: candidates.length > 2,
    hidden: availableCandidateCount <= 2,
  };
}

export function resolveAvailableCandidateCount(chat, state) {
  const activeCharacterCount = resolveActiveCharacterIds(chat).length;
  const normalizedState = normalizeGroupSortState(state);
  const hasPersonaCandidate =
    (typeof chat?.personaId === "string" && chat.personaId.trim()) || normalizedState.personaCandidate;
  return activeCharacterCount + (hasPersonaCandidate ? 1 : 0);
}

async function resolveCandidates(runtime, chat, state) {
  const activeIds = resolveActiveCharacterIds(chat);
  const characterRows = await runtime.resources.listCharacters(activeIds);
  const byId = new Map(characterRows.map((row) => [row.id, readCharacterCandidate(row)]));
  const candidates = activeIds.map((id) => byId.get(id) || { id, name: id, kind: "character", talkativeness: 50 });
  const normalizedState = normalizeGroupSortState(state);
  if (normalizedState.includePersonaCandidate && normalizedState.personaCandidate) {
    candidates.push({ ...normalizedState.personaCandidate, talkativeness: 50 });
  }
  return candidates;
}

async function refreshSmartSelection({ app, runtime, chat, candidates, candidateHash, personaName }) {
  const messages = await runtime.persistence.listMessages(chat.id);
  const anchorMessage = latestAnchorMessage(messages);
  if (!anchorMessage) return null;
  const selectedId = await selectSmartSpeakerViaRaw({ app, runtime, chat, messages, candidates, personaName });
  const selected = candidates.find((candidate) => candidate.id === selectedId) || null;
  if (!selected) {
    await patchChatState(runtime, chat, { candidateHash, byAnchor: {} });
    return null;
  }
  const current = readGroupSortState(chat.metadata);
  const nextState = upsertAnchor(current, {
    messageId: anchorMessage.id,
    swipeIndex: Number.isInteger(anchorMessage.activeSwipeIndex) ? anchorMessage.activeSwipeIndex : 0,
    messageSpeakerId: anchorMessage.characterId ?? "",
    nextSpeakerId: selected.id,
    candidateHash,
  });
  await patchChatState(runtime, chat, nextState);
  return selected;
}

export async function resolveSmartSelectorConnectionId(runtime, chat) {
  const chatConnectionId = typeof chat?.connectionId === "string" && chat.connectionId.trim() ? chat.connectionId : null;
  const resolved = await runtime.languageModels.resolveForRequest({ chatConnectionId });
  return typeof resolved?.connectionId === "string" ? resolved.connectionId.trim() : "";
}

async function selectSmartSpeakerViaRaw({ app, runtime, chat, messages, candidates, personaName }) {
  try {
    const connectionId = await resolveSmartSelectorConnectionId(runtime, chat);
    if (!connectionId) return "";
    const response = await injectJson(app, "POST", "/api/generate/raw", {
      connectionId,
      messages: buildSmartSelectionPrompt({ messages, candidates, personaName }),
      streaming: false,
    });
    return parseSmartGroupSelectionIds(response.content, candidates)[0] || "";
  } catch (error) {
    runtime.logger.warn(error, "[Group Sort Order] refresh selector failed; leaving next speaker unknown");
    return "";
  }
}

function buildSmartSelectionPrompt({ messages, candidates, personaName }) {
  return [
    {
      role: "system",
      content: [
        "You are a hidden response orchestrator for a roleplay group chat.",
        "Choose which character or characters should respond next, based on the latest user message, recent scene context, relevance, personality, and who has spoken recently.",
        "Usually choose exactly one character. Choose multiple only when multiple characters have a strong immediate reason to answer.",
        "Do not always choose the first character. Avoid making the same character speak twice in a row unless the context clearly calls for it.",
        'Return ONLY a valid JSON array of character IDs, such as ["character-id"]. No prose, no object wrapper, no markdown.',
      ].join("\n"),
    },
    {
      role: "user",
      content: [
        `<persona>${personaName}</persona>`,
        "<candidates>",
        formatSmartGroupCandidates(candidates),
        "</candidates>",
        "<recent_transcript>",
        buildRecentTranscript({ messages, candidates, personaName }) || "No recent transcript.",
        "</recent_transcript>",
      ].join("\n"),
    },
  ];
}

function formatSmartGroupCandidates(candidates) {
  return candidates
    .map((candidate) => {
      const fields = [
        `id: ${candidate.id}`,
        `name: ${candidate.name}`,
        `talkativeness: ${normalizeTalkativenessPercent(candidate.talkativeness)}%`,
        candidate.status !== undefined ? `current status: ${candidate.status}` : null,
        candidate.activity ? `current activity: ${candidate.activity}` : null,
        candidate.personality ? `personality: ${String(candidate.personality).slice(0, 500)}` : null,
        candidate.description ? `description: ${String(candidate.description).slice(0, 500)}` : null,
      ].filter((field) => field !== null);
      return fields.map((field, index) => `${index === 0 ? "- " : "  "}${field}`).join("\n");
    })
    .join("\n\n");
}

function buildRecentTranscript({ messages, candidates, personaName }) {
  return messages
    .filter((message) => message.role === "user" || message.role === "assistant")
    .slice(-5)
    .map((message) => {
      const speaker = resolveMessageSpeakerName(message, candidates, personaName);
      const content = stripTerminalNextSpeakerMarker(String(message.content || ""))
        .replace(/\s+/g, " ")
        .trim()
        .slice(0, 900);
      return content ? `${speaker}: ${content}` : "";
    })
    .filter(Boolean)
    .join("\n");
}

function resolveMessageSpeakerName(message, candidates, personaName) {
  if (message.role === "user") return personaName;
  if (message.characterId) return candidates.find((candidate) => candidate.id === message.characterId)?.name ?? "Character";
  return "the narrator";
}

function latestAnchorMessage(messages) {
  return [...messages].reverse().find((message) => message?.id && (message.role === "user" || message.role === "assistant")) ?? null;
}

function readCharacterCandidate(row) {
  const parsed = normalizeObject(row.data);
  return {
    id: row.id,
    name: typeof parsed.name === "string" && parsed.name.trim() ? parsed.name.trim() : row.id,
    kind: "character",
    talkativeness: normalizeTalkativenessPercent(parsed.talkativeness),
    personality: typeof parsed.personality === "string" ? parsed.personality.slice(0, 500) : "",
    description: typeof parsed.description === "string" ? parsed.description.slice(0, 500) : "",
  };
}

function normalizeTalkativenessPercent(value) {
  const numeric = Number(value);
  if (!Number.isFinite(numeric)) return 50;
  const percent = numeric <= 1 ? numeric * 100 : numeric;
  return Math.max(0, Math.min(100, Math.round(percent)));
}

function resolvePersonaName(chat, candidates, state) {
  const personaId = typeof chat.personaId === "string" ? chat.personaId : "";
  const statePersona = normalizeGroupSortState(state).personaCandidate;
  return candidates.find((candidate) => candidate.id === personaId)?.name ?? statePersona?.name ?? "Persona";
}

function normalizePersonaCandidate(value) {
  const obj = normalizeObject(value);
  if (typeof obj.id !== "string" || !obj.id.trim()) return null;
  return {
    id: obj.id,
    name: typeof obj.name === "string" && obj.name.trim() ? obj.name.trim() : obj.id,
    kind: "persona",
  };
}

function readString(value) {
  return typeof value === "string" && value.trim() ? value.trim() : "";
}

function hasVisibleIncomingUserTurn(body) {
  if (typeof body.userMessage === "string" && body.userMessage.trim()) return true;
  if (Array.isArray(body.attachments) && body.attachments.length > 0) return true;
  return Boolean(normalizeObject(body.pendingSpatialTransition).commandId);
}

function reconcileGroupSortPromptContribution(chatId, candidates) {
  if (!Array.isArray(candidates) || candidates.length <= 2) {
    clearGroupSortPromptContribution(chatId);
    return null;
  }
  return setPromptContribution(chatId, {
    agentType: GROUP_SORT_ORDER_AGENT_TYPE,
    agentName: "Group Sort Order",
    text: buildInstructionText(candidates),
  });
}

function clearGroupSortPromptContribution(chatId) {
  return clearPromptContribution(chatId, GROUP_SORT_ORDER_AGENT_TYPE);
}

async function patchChatState(runtime, chat, statePatch) {
  const currentMetadata = normalizeObject(chat.metadata);
  await runtime.persistence.updateChatMetadata({
    chatId: chat.id,
    metadata: writeGroupSortState(currentMetadata, statePatch),
    updatedAt: new Date().toISOString(),
  });
}

function installOutgoingMarkerFilter(reply, requestState) {
  const raw = reply?.raw;
  if (!raw || typeof raw.write !== "function" || raw.__groupSortOrderMarkerFilterInstalled) return;
  const originalWrite = raw.write.bind(raw);
  raw.__groupSortOrderMarkerFilterInstalled = true;
  raw.write = (chunk, encoding, callback) => {
    const sanitized = sanitizeOutgoingSseChunk(chunk, requestState);
    return originalWrite(sanitized, encoding, callback);
  };
}

async function injectJson(app, method, url, payload) {
  return injectHostJson(app, method, url, payload, { internalHeader: INTERNAL_HEADER });
}

function isInternalRequest(request) {
  const value = request.headers?.[INTERNAL_HEADER];
  return value === "1" || value === "true" || (Array.isArray(value) && value.includes("1"));
}

function chunkToString(chunk) {
  if (typeof chunk === "string") return chunk;
  if (Buffer.isBuffer(chunk)) return chunk.toString("utf8");
  return "";
}
