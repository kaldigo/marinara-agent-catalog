const cleanupWorldMapBackgroundClient = await activateClientWithMariBridge(
  {
    consumerId: "world-map-background",
    api: { major: 1, minMinor: 0 },
    require: ["chat.active", "client.bridge-first", "consumer.sessions", "generation.lifecycle", "runtime.health", "ui.agent-settings"],
  },
  async (bridgeSession) => {
    const PACKAGE_ID = "world-map-background";
    const WORLD_MAPS_AGENT_ID = "hierarchical-maps";
    const TAG_NAME = "marinara-capability-world-map-background";
    const CAPABILITY_SERVER_EVENT = "marinara-capability-server-event";
    const GLOBAL_GALLERY_PREFIX = "global-gallery:";
    const state = { activeChatId: "", syncing: new Map(), elements: new Set() };

    class WorldMapBackgroundElement extends HTMLElement {
      connectedCallback() {
        state.elements.add(this);
        this.addEventListener("marinara-capability-props", this);
        this.addEventListener("input", this);
        void this.render();
      }
      disconnectedCallback() {
        state.elements.delete(this);
        this.removeEventListener("marinara-capability-props", this);
        this.removeEventListener("input", this);
      }
      handleEvent(event) {
        if (event.type === "input") {
          const input = event.target instanceof HTMLInputElement ? event.target : null;
          if (input?.matches("[data-wmb-blur]")) void saveBlur(this.chatId, Number(input.value));
          return;
        }
        void this.render();
      }
      get chatId() {
        return typeof this.capabilityProps?.chatId === "string"
          ? this.capabilityProps.chatId
          : bridgeSession.chat.active.getSnapshot().chatId || "";
      }
      async render() {
        if (this.getAttribute("view") !== "settings" || !this.chatId) {
          this.hidden = true;
          this.replaceChildren();
          return;
        }
        this.hidden = false;
        const chat = await api(`/chats/${encodeURIComponent(this.chatId)}`).catch(() => null);
        if (!chat || !this.isConnected) return;
        const metadata = record(chat.metadata);
        const settings = record(metadata.worldMapBackground);
        const blur = clampBlur(settings.blur);
        this.innerHTML = `<label class="flex flex-col gap-2 rounded-lg bg-[var(--background)]/75 px-3 py-2.5 ring-1 ring-[var(--border)]">
          <span class="flex items-center justify-between gap-3 text-xs"><span>Location background blur</span><strong>${blur}px</strong></span>
          <input data-wmb-blur type="range" min="0" max="24" step="1" value="${blur}" aria-label="Location background blur">
          <span class="text-[0.625rem] leading-snug text-[var(--muted-foreground)]">The native Roleplay background renderer applies this when the active World Maps location supplies an image.</span>
        </label>`;
      }
    }

    if (!customElements.get(TAG_NAME)) customElements.define(TAG_NAME, WorldMapBackgroundElement);

    const disposeSettings = bridgeSession.ui.register({
      id: "settings",
      slot: "agent.settings",
      agentIds: [PACKAGE_ID],
      view: "settings",
    });
    const disposeChat = bridgeSession.chat.active.subscribe(({ chatId }) => {
      state.activeChatId = chatId || "";
      if (state.activeChatId) void synchronize(state.activeChatId);
    });
    const disposeGeneration = bridgeSession.generation.subscribe((snapshot, event) => {
      if (!snapshot.mainActive && event?.detail?.chatId) void synchronize(event.detail.chatId);
    }, { emitCurrent: false });
    const onCapabilityEvent = (event) => {
      const detail = record(event?.detail);
      if (detail.packageId !== WORLD_MAPS_AGENT_ID) return;
      if (["spatial_transition_committed", "spatial_context_refresh"].includes(detail.type)) {
        void synchronize(detail.chatId || state.activeChatId);
      }
    };
    window.addEventListener(CAPABILITY_SERVER_EVENT, onCapabilityEvent);

    async function synchronize(chatId) {
      if (!chatId) return;
      if (state.syncing.has(chatId)) return state.syncing.get(chatId);
      const operation = runSynchronization(chatId).finally(() => state.syncing.delete(chatId));
      state.syncing.set(chatId, operation);
      return operation;
    }

    async function runSynchronization(chatId) {
      const chat = await api(`/chats/${encodeURIComponent(chatId)}`).catch(() => null);
      if (!chat) return;
      const metadata = record(chat.metadata);
      const settings = record(metadata.worldMapBackground);
      const activeIds = Array.isArray(metadata.activeAgentIds) ? metadata.activeAgentIds : [];
      const active = chat.mode === "roleplay" && metadata.enableAgents === true
        && activeIds.includes(PACKAGE_ID) && activeIds.includes(WORLD_MAPS_AGENT_ID);
      const image = active ? await resolveCurrentLocationImage(chatId).catch(() => null) : null;

      if (!image) {
        if (settings.currentUrl && metadata.background === settings.currentUrl) {
          await patchMetadata(chatId, {
            background: settings.previousBackground ?? null,
            worldMapBackground: { blur: clampBlur(settings.blur) },
          });
        }
        return;
      }

      const previousBackground = metadata.background && metadata.background !== settings.currentUrl
        ? metadata.background
        : settings.previousBackground ?? null;
      if (metadata.background === image.url && settings.currentUrl === image.url) return;
      await patchMetadata(chatId, {
        background: image.url,
        worldMapBackground: {
          blur: clampBlur(settings.blur),
          currentUrl: image.url,
          previousBackground,
          referenceImageId: image.referenceImageId,
        },
      });
    }

    async function resolveCurrentLocationImage(chatId) {
      const spatial = await api(`/chats/${encodeURIComponent(chatId)}/spatial-context`);
      const definition = record(spatial?.definition);
      if (definition.enabled === false) return null;
      const currentLocationId = typeof spatial?.currentLocationId === "string" ? spatial.currentLocationId.trim() : "";
      const current = (Array.isArray(definition.locations) ? definition.locations : [])
        .find((location) => location?.id === currentLocationId && location?.status !== "archived");
      if (!current || current.useReferenceImage !== true) return null;
      const referenceImageId = typeof current.referenceImageId === "string" ? current.referenceImageId.trim() : "";
      if (!referenceImageId) return null;
      const [chatImages, globalImages] = await Promise.all([
        api(`/gallery/${encodeURIComponent(chatId)}`).catch(() => []),
        api("/global-gallery").catch(() => []),
      ]);
      const image = resolveGalleryImage(referenceImageId, chatImages, globalImages);
      return image?.url ? { referenceImageId, url: image.url } : null;
    }

    function resolveGalleryImage(referenceImageId, chatImages, globalImages) {
      const chatMatch = array(chatImages).find((image) => image?.id === referenceImageId);
      if (chatMatch) return chatMatch;
      const globalId = referenceImageId.startsWith(GLOBAL_GALLERY_PREFIX)
        ? referenceImageId.slice(GLOBAL_GALLERY_PREFIX.length).trim()
        : referenceImageId;
      return array(globalImages).find((image) => image?.id === globalId || referenceImageId === `${GLOBAL_GALLERY_PREFIX}${image?.id}`);
    }

    async function saveBlur(chatId, blur) {
      if (!chatId) return;
      const chat = await api(`/chats/${encodeURIComponent(chatId)}`);
      const metadata = record(chat.metadata);
      await patchMetadata(chatId, {
        worldMapBackground: { ...record(metadata.worldMapBackground), blur: clampBlur(blur) },
      });
      for (const element of state.elements) if (element.chatId === chatId) void element.render();
    }

    return () => {
      window.removeEventListener(CAPABILITY_SERVER_EVENT, onCapabilityEvent);
      disposeGeneration();
      disposeChat();
      disposeSettings();
    };
  },
);

function record(value) {
  if (typeof value === "string") {
    try { value = JSON.parse(value || "{}"); } catch { return {}; }
  }
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}

function array(value) {
  return Array.isArray(value) ? value : Array.isArray(value?.images) ? value.images : [];
}

function clampBlur(value) {
  return Math.max(0, Math.min(24, Math.round(Number(value) || 0)));
}

async function patchMetadata(chatId, patch) {
  return api(`/chats/${encodeURIComponent(chatId)}/metadata`, {
    method: "PATCH",
    headers: { "x-marinara-csrf": "1" },
    body: JSON.stringify(patch),
  });
}

async function api(path, options = {}) {
  const headers = { Accept: "application/json", ...(options.headers ?? {}) };
  if (options.body !== undefined) headers["Content-Type"] = "application/json";
  const response = await fetch(`/api${path}`, { credentials: "same-origin", ...options, headers });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data?.error || `World Map Background request failed (${response.status})`);
  return data;
}

void cleanupWorldMapBackgroundClient;
